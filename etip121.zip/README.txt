etip121.zip - Encrypt Text in Picture 1.2.1

http://wargame.dyns.cx/
