
http://wargame.dyns.cx/
http://hackerfun.com/